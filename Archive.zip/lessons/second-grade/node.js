function playSound(spath){
    var audio = new Audio();
    audio.src = spath
    audio.play()
}